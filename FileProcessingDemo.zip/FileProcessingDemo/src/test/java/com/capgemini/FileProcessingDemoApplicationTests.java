package com.capgemini;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import com.capgemini.model.Sentence;

@WebMvcTest({ FileProcessingDemoApplication.class })
@ExtendWith(SpringExtension.class)
@TestInstance(Lifecycle.PER_CLASS)
class FileProcessingDemoApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	FileProcessingService fileProcessingService;

	@InjectMocks
	FileProcessingDemoApplication applicaion;

	@Mock
	Map<Sentence, String> value;

	@Mock
	Map<Sentence, List<String>> mapOfSentence;

	private File files;
	private FileInputStream fis;
	private byte[] bytes;
	private MockMultipartFile file;

	@BeforeEach
	public void setUp() throws IOException {
		files = new File("src\\test\\resources\\small.in");
		fis = new FileInputStream(files);
		bytes = fis.readAllBytes();
		file = new MockMultipartFile("file", bytes);
	}

	@Test
	public void testGetCSVFormat() throws Exception {
		when(fileProcessingService.toXmlFormat(file)).thenReturn(mapOfSentence);
		MvcResult result = mockMvc.perform(multipart("/api/get-csv").file(file)).andDo(print())
				.andExpect(status().isOk()).andReturn();
		System.out.println(result.getResponse().getContentAsString());
		assertNotNull(result.getResponse().getContentAsString());
	}

	@Test
	public void testGetXMLFormat() throws Exception {
		when(fileProcessingService.toCSVFormat(file)).thenReturn(value);
		MvcResult result = mockMvc.perform(multipart("/api/get-xml").file(file)).andDo(print())
				.andExpect(status().isOk()).andReturn();
		System.out.println(result.getResponse().getContentAsString());
		assertNotNull(result.getResponse().getContentAsString());
	}
}
