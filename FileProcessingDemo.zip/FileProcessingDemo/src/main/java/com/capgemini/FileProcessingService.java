package com.capgemini;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.capgemini.model.Sentence;

@Service
public class FileProcessingService {

	public Map<Sentence, List<String>> xmlmap;
	public Map<Sentence, String> csvmap;

	public Map<Sentence, List<String>> toXmlFormat(MultipartFile file) {
		StringBuffer sortedWord = new StringBuffer();
		xmlmap = new HashMap<>();
		try {
			byte[] bytes = file.getBytes();
			String text = new String(bytes, StandardCharsets.UTF_8);
			String[] sentenceArray = text.split("(?<=[.!?])\\s*");
			for (int i = 0; i < sentenceArray.length; i++) {
				Sentence sen = new Sentence();
				sen.setSentence(sentenceArray[i]);
				String[] word = sentenceArray[i].split("\\s");
				List<String> listofword = Stream.of(word).distinct().sorted()
						.filter(val -> !(val.equals(",") || val.equals(" ") || val.equals("-")))
						.filter(Predicate.not(String::isEmpty)).collect(Collectors.toList());
				xmlmap.put(sen, listofword);
				sortedWord.delete(0, sortedWord.length());
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return xmlmap;
	}

	public Map<Sentence, String> toCSVFormat(MultipartFile file) {
		StringBuffer sortedWord = new StringBuffer();
		csvmap = new HashMap<>();
		try {
			byte[] bytes = file.getBytes();
			String text = new String(bytes, StandardCharsets.UTF_8);
			String[] sentenceArray = text.split("(?<=[.!?])\\s*");
			for (int i = 0; i < sentenceArray.length; i++) {
				Sentence csvsen = new Sentence();
				csvsen.setSentence(sentenceArray[i]);
				String[] word = sentenceArray[i].split("\\s");
				getCSVFileFormat(word, sortedWord);
				csvmap.put(csvsen, sortedWord.toString());
				sortedWord.delete(0, sortedWord.length());
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return csvmap;
	}

	private void getCSVFileFormat(String[] word, StringBuffer sortedWord) {
		Stream.of(word).distinct().sorted().filter(val -> !(val.equals(",") || val.equals(" ") || val.equals("-")))
				.filter(Predicate.not(String::isEmpty)).forEach(action -> {
					sortedWord.append(action).append(",");
				});
	}

}
