package com.capgemini.model;

public class Sentence implements Comparable<String>{

	private String sentence;

	public String getSentence() {
		return sentence;
	}

	public void setSentence(String sentence) {
		this.sentence = sentence;
	}

	@Override
	public int compareTo(String o) {
		// TODO Auto-generated method stub
		return this.sentence.compareTo(o);
	}

	@Override
	public String toString() {
		return "Sentence [" + sentence + "]";
	}
	
	
	
	
}
