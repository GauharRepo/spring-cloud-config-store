package com.capgemini.model;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ListXmlSentence implements Serializable{

	//@XmlElementWrapper(name="sentence")
	private List<XmlSentence> sentences;

	public List<XmlSentence> getSentences() {
		return sentences;	
	}

	public void setSentences(List<XmlSentence> sentences) {
		this.sentences = sentences;
	}


}
