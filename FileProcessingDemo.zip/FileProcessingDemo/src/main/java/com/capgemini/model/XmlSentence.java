package com.capgemini.model;

import java.io.Serializable;
import java.util.List;

public class XmlSentence implements Serializable {

	private String sentence;
	private List<String> word;

	
	public List<String> getWord() {
		return word;
	}

	public void setWord(List<String> word) {
		this.word = word;
	}

	public String getSentence() {
		return sentence;
	}

	public void setSentence(String sentence) {
		this.sentence = sentence;
	}

}
