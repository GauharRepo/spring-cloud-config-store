package com.capgemini;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.capgemini.model.ListXmlSentence;
import com.capgemini.model.Sentence;
import com.capgemini.model.XmlSentence;

import lombok.extern.log4j.Log4j2;

@Log4j2
@SpringBootApplication
@RestController
@RequestMapping("/api")
public class FileProcessingDemoApplication {

	@Autowired
	FileProcessingService fileProcessingService;

	public static void main(String[] args) {
		SpringApplication.run(FileProcessingDemoApplication.class, args);
	}

	@PostMapping(path = { "/get-xml" }, produces = "application/xml")
	public ResponseEntity<ListXmlSentence> getXMLFormat(@RequestParam("file") MultipartFile file) {
		ListXmlSentence xml=new ListXmlSentence();
		List<XmlSentence> sentences = new ArrayList<>();
		Map<Sentence, List<String>> mapOfSentence = fileProcessingService.toXmlFormat(file);
		mapOfSentence.entrySet().stream().forEach(action -> {
			XmlSentence xmlSentence = new XmlSentence();
			xmlSentence.setSentence(action.getKey().getSentence());
			xmlSentence.setWord(action.getValue());
			sentences.add(xmlSentence);
		});
		xml.setSentences(sentences);
		
		return ResponseEntity.ok(xml);
	}

	@PostMapping(path = { "/get-csv" })
	public ResponseEntity<Map<Sentence, String>> getCSVFormat(@RequestParam("file") MultipartFile file) {
		Map<Sentence, String> mapOfSentence = fileProcessingService.toCSVFormat(file);
		return ResponseEntity.ok(mapOfSentence);

	}
	
}
